Biki's Astro cloud-build package. The GitHub Actions workflow uses JDK 17 and Gradle to build app-debug.apk.
