@echo off
where gradle >nul 2>nul
if %errorlevel%==0 (gradle %*) else (echo Gradle executable not found.)
