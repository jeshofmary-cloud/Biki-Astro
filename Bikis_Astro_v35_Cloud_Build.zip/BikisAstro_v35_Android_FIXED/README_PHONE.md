Biki's Astro v35 - AndroidIDE project

This package includes a Gradle launcher (gradlew). Open the project root (the folder containing app, build.gradle and settings.gradle) in AndroidIDE.
Then use Run/Quick Run.
